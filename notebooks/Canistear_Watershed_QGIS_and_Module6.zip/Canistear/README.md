﻿# Canistear Reservoir watershed package

Open `notebooks/06_canistear-watershed/Module6_CanistearWatershed_USGS.ipynb` for the new module.
Open `notebooks/06_canistear-watershed/Canistear_Data/Canistear.qgs` in QGIS.
Open `Canistear_map.html` in that data folder for the interactive map.

Keep the project beside its GeoPackage. All paths in QGIS are relative. The online Esri basemap requires internet; vectors are offline. PNG is an offline overview. Read the notebook for methods, limitations, and regeneration instructions.

Results: 3 sites inside the basin; 2 buffer-only sites; 2 km buffer. All USGS site types/statuses, no parameter filter. NLDI basin: 15.05 km² (5.81 mi²), about 4.5% smaller than published USGS 6.08 mi². This is an NLDI basin retrieval, not a new DEM delineation. Review the discrepancy before engineering use.

The `notebooks/06_canistear-watershed` folder is ready to add to the repository's notebook section. No change to the GitHub repository is implied by this local package.
