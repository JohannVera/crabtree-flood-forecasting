from pathlib import Path
import json, io, datetime, html
import requests
import pandas as pd
import geopandas as gpd
from shapely.geometry import shape

# Reusable study settings: change these for another USGS outlet.
OUTLET_SITE = '01382100'
STUDY_NAME = 'Canistear Reservoir contributing watershed'
BUFFER_DISTANCE_KM = 2.0
PROJECTED_CRS = 32618  # UTM 18N; select the local metric CRS for another region.
PUBLISHED_AREA_SQMI = 6.08  # Optional independent area check; update for another site.

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'Canistear_Data'
OUT.mkdir(parents=True, exist_ok=True)
RAW = OUT / 'sources'; RAW.mkdir(exist_ok=True)
session = requests.Session()
log = []
def fetch(url, params, name):
    r = session.get(url, params=params, timeout=90); r.raise_for_status()
    (RAW / name).write_text(r.text, encoding='utf-8')
    log.append({'url':r.url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file':name})
    return r

basin_json = fetch(f'https://api.water.usgs.gov/nldi/linked-data/nwissite/USGS-{OUTLET_SITE}/basin', {'simplified':'false'}, 'nldi_basin.geojson').json()
basin = gpd.GeoDataFrame.from_features(basin_json['features'], crs=4326).to_crs(PROJECTED_CRS)
basin = gpd.GeoDataFrame({'name':[STUDY_NAME]}, geometry=[basin.geometry.union_all()], crs=PROJECTED_CRS)
area = basin.area.iloc[0]/1e6
basin['area_km2'] = area; basin['area_sqmi'] = area/2.589988110336
buffer = basin.copy(); buffer['name'] = f'{BUFFER_DISTANCE_KM:g} km watershed search buffer'; buffer.geometry = basin.buffer(BUFFER_DISTANCE_KM * 1000)
ring = buffer.copy(); ring['name'] = f'{BUFFER_DISTANCE_KM:g} km buffer outside watershed'; ring.geometry = buffer.geometry.difference(basin.geometry.iloc[0])
w,s,e,n = buffer.to_crs(4326).total_bounds
params = {'format':'rdb','bBox':f'{w:.7f},{s:.7f},{e:.7f},{n:.7f}','siteStatus':'all','siteOutput':'expanded'}
r = fetch('https://waterservices.usgs.gov/nwis/site/', params, 'nwis_sites.rdb')
lines = [x for x in r.text.splitlines() if x and not x.startswith('#')]
df = pd.read_csv(io.StringIO('\n'.join([lines[0]]+lines[2:])), sep='\t', dtype=str).fillna('')
assert len(df)>0, 'No station response; do not produce an empty catalog.'
df['dec_lat_va'] = pd.to_numeric(df.dec_lat_va, errors='coerce'); df['dec_long_va'] = pd.to_numeric(df.dec_long_va, errors='coerce')
assert df[['dec_lat_va','dec_long_va']].notna().all().all(), 'Missing coordinates require review.'
sites = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.dec_long_va,df.dec_lat_va), crs=4326).to_crs(PROJECTED_CRS)
sites = sites[sites.geometry.intersects(buffer.geometry.iloc[0])].copy().drop_duplicates('site_no')
sites['location_type'] = ['watershed' if basin.geometry.iloc[0].covers(p) else 'buffer_only' for p in sites.geometry]
sites['distance_to_basin_km'] = sites.distance(basin.geometry.iloc[0])/1000
sites['distance_to_centroid_km'] = sites.distance(basin.geometry.iloc[0].centroid)/1000
sites['usgs_url'] = 'https://waterdata.usgs.gov/monitoring-location/USGS-'+sites.site_no+'/'
sites = sites.sort_values(['location_type','site_no'])
layers = {'watershed':basin,'search_buffer':buffer,'buffer_only_zone':ring,'usgs_sites':sites,
          'sites_in_basin':sites[sites.location_type=='watershed'].copy(), 'sites_buffer_only':sites[sites.location_type=='buffer_only'].copy()}
gpkg = OUT/'Canistear.gpkg'
if gpkg.exists(): gpkg.unlink()
for name, frame in layers.items():
    frame.to_file(gpkg,layer=name,driver='GPKG')
    frame.to_crs(4326).to_file(OUT/(name+'.geojson'),driver='GeoJSON')
sites.drop(columns='geometry').to_csv(OUT/'usgs_station_catalog.csv',index=False)
summary = {'watershed_area_km2':area,'watershed_area_sqmi':area/2.589988110336,'published_usgs_area_sqmi':PUBLISHED_AREA_SQMI,
 'basin_sites':int((sites.location_type=='watershed').sum()),'buffer_only_sites':int((sites.location_type=='buffer_only').sum()),
 'total_sites':len(sites),'buffer_km':BUFFER_DISTANCE_KM,'crs':f'EPSG:{PROJECTED_CRS}','method':f'USGS NLDI unsimplified upstream basin for USGS-{OUTLET_SITE}; not a new DEM delineation',
 'scope':'All NWIS site types, all statuses, no parameter filter; exact polygon intersection after bounding-box query',
 'sources':log}
(OUT/'metadata.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='sources'},indent=2))

# Module 5-style interactive map, with separate station groups and USGS popups.
data = {k:json.loads(v.to_crs(4326).to_json()) for k,v in layers.items() if k in ['watershed','search_buffer','sites_in_basin','sites_buffer_only']}
page = '''<!doctype html><html><head><meta charset="utf-8"><title>Canistear Reservoir watershed and USGS stations</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>body{margin:0;font:15px Arial}#map{height:88vh}header{padding:12px 20px}h2{margin:0 0 6px} .legend{background:white;padding:12px;line-height:1.6}</style></head><body>
<header><h2>Canistear Reservoir contributing watershed</h2>AREA km² Â· INSIDE sites in basin Â· OUTSIDE sites in BUFFER_LABEL buffer only Â· All USGS site types and statuses</header><div id="map"></div>
<script>const data=DATA; const map=L.map('map');
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',{attribution:'Tiles © Esri and the GIS User Community'}).addTo(map);
const buf=L.geoJSON(data.search_buffer,{style:{color:'#3388cc',weight:1,fillOpacity:.16}}).addTo(map);
const basin=L.geoJSON(data.watershed,{style:{color:'#173d89',weight:3,fillOpacity:.35}}).addTo(map);
function safe(s){const d=document.createElement('div');d.textContent=s||'';return d.innerHTML}
function points(fc,color){return L.geoJSON(fc,{pointToLayer:(f,ll)=>L.circleMarker(ll,{radius:5,color:'#fff',weight:1,fillColor:color,fillOpacity:.9}),onEachFeature:(f,l)=>{const p=f.properties;l.bindTooltip(p.site_no+' '+p.station_nm);l.bindPopup('<b>USGS '+safe(p.site_no)+'</b><br>'+safe(p.station_nm)+'<br>Type: '+safe(p.site_tp_cd)+'<br>Zone: '+safe(p.location_type)+'<br>Distance to basin: '+Number(p.distance_to_basin_km).toFixed(2)+' km<br><a target="_blank" rel="noopener" href="'+p.usgs_url+'">USGS station page</a>')}}).addTo(map)}
const inside=points(data.sites_in_basin,'#16834b'),outside=points(data.sites_buffer_only,'#ed8b23');
L.control.layers(null,{f'{BUFFER_DISTANCE_KM:g} km search buffer':buf,'Contributing watershed':basin,'USGS sites in basin':inside,'USGS sites in buffer only':outside}).addTo(map);
map.fitBounds(buf.getBounds());const legend=L.control({position:'bottomleft'});legend.onAdd=()=>{const d=L.DomUtil.create('div','legend');d.innerHTML='● USGS site in basin<br>● USGS site in buffer only<br>Blue: watershed and BUFFER_LABEL buffer<br>Source: USGS NLDI / NWIS';return d};legend.addTo(map);</script></body></html>'''
page = page.replace('Canistear Reservoir contributing watershed', html.escape(STUDY_NAME)).replace('BUFFER_LABEL', f'{BUFFER_DISTANCE_KM:g} km').replace('AREA',f'{area:.2f}').replace('INSIDE',str(summary['basin_sites'])).replace('OUTSIDE',str(summary['buffer_only_sites'])).replace('DATA',json.dumps(data))
(OUT/'Canistear_map.html').write_text(page,encoding='utf-8')

def make_qgis():
    import os
    dll_handles = []
    if os.name == 'nt':
        for directory in ['C:/Program Files/QGIS 3.44.1/bin','C:/Program Files/QGIS 3.44.1/apps/Qt5/bin','C:/Program Files/QGIS 3.44.1/apps/qgis/bin']:
            if Path(directory).exists(): dll_handles.append(os.add_dll_directory(directory))
    from qgis.core import (QgsApplication,QgsProject,QgsVectorLayer,QgsCoordinateReferenceSystem,QgsFillSymbol,QgsMarkerSymbol,QgsRasterLayer,QgsRectangle,QgsMapSettings,QgsMapRendererParallelJob)
    from qgis.PyQt.QtCore import QSize
    from qgis.PyQt.QtGui import QColor
    app=QgsApplication.instance()
    if app is None:
        app=QgsApplication([],False);app.initQgis()
    project=QgsProject.instance();project.clear();project.setCrs(QgsCoordinateReferenceSystem(f'EPSG:{PROJECTED_CRS}'))
    project.setFileName(str(OUT/'Canistear.qgs'))
    project.setTitle('Canistear Reservoir contributing watershed and all USGS sites')
    basemap=QgsRasterLayer('type=xyz&url=https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/%7Bz%7D/%7By%7D/%7Bx%7D','Esri World Street Map (internet required)','wms')
    project.addMapLayer(basemap)
    qlayers=[]
    styles=[('search_buffer',f'{BUFFER_DISTANCE_KM:g} km search buffer','110,180,235,45','50,110,190,255'),('watershed',STUDY_NAME,'30,65,145,95','20,50,125,255'),('sites_buffer_only',f'USGS buffer only ({summary["buffer_only_sites"]})','#ed8b23',None),('sites_in_basin',f'USGS in basin ({summary["basin_sites"]})','#16834b',None)]
    for key,title,fill,stroke in styles:
        layer=QgsVectorLayer(str(gpkg)+'|layername='+key,title,'ogr');assert layer.isValid(),key
        symbol=QgsFillSymbol.createSimple({'color':fill,'outline_color':stroke,'outline_width':'0.6'}) if stroke else QgsMarkerSymbol.createSimple({'name':'circle','color':fill,'outline_color':'white','size':'2.5'})
        layer.renderer().setSymbol(symbol);project.addMapLayer(layer);qlayers.insert(0,layer)
    extent=QgsRectangle(*buffer.total_bounds);extent.scale(1.06)
    project.viewSettings().setDefaultViewExtent(__import__('qgis.core',fromlist=['QgsReferencedRectangle']).QgsReferencedRectangle(extent,project.crs()))
    assert project.write(), 'Project save failed'
    # Export an offline map: vector data remain readable without external tiles.
    settings=QgsMapSettings();settings.setLayers(qlayers);settings.setDestinationCrs(project.crs());settings.setExtent(extent);settings.setOutputSize(QSize(1600,1400));settings.setBackgroundColor(QColor('#f4f7fa'))
    job=QgsMapRendererParallelJob(settings);job.start();job.waitForFinished();job.renderedImage().save(str(OUT/'Canistear_map.png'))
    # Reopen to verify relative paths and layer validity.
    project.clear();assert project.read(str(OUT/'Canistear.qgs'))
    assert all(x.isValid() for x in project.mapLayers().values()), 'Invalid project layer'
    print('QGIS project saved and reopened; all layers valid.')

if __name__=='__main__':
    make_qgis()

