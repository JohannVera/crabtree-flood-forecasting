# Module 7: Oak Ridge Reservoir contributing watershed

Open Module7_OakRidgeWatershed_USGS.ipynb in Colab or Jupyter. In Colab, uncomment and run the pip-install cell, then run the notebook in order. Skip the optional QGIS cell in Colab.

The package includes the successfully retrieved basin, 2 km search buffer, all discovered USGS stations, CSV catalog, interactive map and provenance. Open OakRidge_Data/OakRidge.gpkg directly in QGIS. The optional notebook function make_qgis() creates a styled project and vector PNG when run in QGIS Python after the setup/data cells.

Outlet: USGS 01382200. Basin area 69.73 km². USGS published area 27.3 mi², a -1.37% difference. Inventory snapshot: 7 basin stations and 10 buffer-only stations. Exact polygon filtering uses UTM 18N.

Suggested repository destinations:
- notebooks/Module7_OakRidgeWatershed_USGS.ipynb
- notebooks/07_oakridge-watershed/ (supporting files and OakRidge_Data)

Repository notebook: notebooks/Module7_OakRidgeWatershed_USGS.ipynb

The original Module 6 remains unchanged.
