# %pip install requests pandas geopandas shapely pyproj pyogrio
from pathlib import Path


from pathlib import Path
import json, io, datetime, html
import requests
import pandas as pd
import geopandas as gpd
from shapely.geometry import shape



# Reusable study settings: change these for another USGS outlet.
OUTLET_SITE = '01382200'
STUDY_NAME = 'Oak Ridge Reservoir contributing watershed'
BUFFER_DISTANCE_KM = 2.0
PROJECTED_CRS = 32618  # UTM 18N; select the local metric CRS for another region.
PUBLISHED_AREA_SQMI = 27.3  # Optional independent area check; update for another site.



ROOT = Path.cwd()
OUT = ROOT / 'OakRidge_Data'
OUT.mkdir(parents=True, exist_ok=True)
RAW = OUT / 'sources'; RAW.mkdir(exist_ok=True)
session = requests.Session()
log = []
def fetch(url, params, name):
    r = session.get(url, params=params, timeout=90); r.raise_for_status()
    (RAW / name).write_text(r.text, encoding='utf-8')
    log.append({'url':r.url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file':name})
    return r



basin_json = fetch(f'https://api.water.usgs.gov/nldi/linked-data/nwissite/USGS-{OUTLET_SITE}/basin', {'simplified':'false'}, 'nldi_basin.geojson').json()
basin = gpd.GeoDataFrame.from_features(basin_json['features'], crs=4326).to_crs(PROJECTED_CRS)
basin = gpd.GeoDataFrame({'name':[STUDY_NAME]}, geometry=[basin.geometry.union_all()], crs=PROJECTED_CRS)
area = basin.area.iloc[0]/1e6
basin['area_km2'] = area; basin['area_sqmi'] = area/2.589988110336

if PUBLISHED_AREA_SQMI:
    area_difference_pct = 100 * (area / 2.589988110336 - PUBLISHED_AREA_SQMI) / PUBLISHED_AREA_SQMI
    print(f'NLDI area: {area:.2f} km²; published USGS: {PUBLISHED_AREA_SQMI:g} mi²; difference: {area_difference_pct:+.2f}%')


buffer = basin.copy(); buffer['name'] = f'{BUFFER_DISTANCE_KM:g} km watershed search buffer'; buffer.geometry = basin.buffer(BUFFER_DISTANCE_KM * 1000)
ring = buffer.copy(); ring['name'] = f'{BUFFER_DISTANCE_KM:g} km buffer outside watershed'; ring.geometry = buffer.geometry.difference(basin.geometry.iloc[0])


w,s,e,n = buffer.to_crs(4326).total_bounds
params = {'format':'rdb','bBox':f'{w:.7f},{s:.7f},{e:.7f},{n:.7f}','siteStatus':'all','siteOutput':'expanded'}
r = fetch('https://waterservices.usgs.gov/nwis/site/', params, 'nwis_sites.rdb')
lines = [x for x in r.text.splitlines() if x and not x.startswith('#')]
df = pd.read_csv(io.StringIO('\n'.join([lines[0]]+lines[2:])), sep='\t', dtype=str).fillna('')
assert len(df)>0, 'No station response; do not produce an empty catalog.'
df['dec_lat_va'] = pd.to_numeric(df.dec_lat_va, errors='coerce'); df['dec_long_va'] = pd.to_numeric(df.dec_long_va, errors='coerce')
assert df[['dec_lat_va','dec_long_va']].notna().all().all(), 'Missing coordinates require review.'


sites = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.dec_long_va,df.dec_lat_va), crs=4326).to_crs(PROJECTED_CRS)
sites = sites[sites.geometry.intersects(buffer.geometry.iloc[0])].copy().drop_duplicates('site_no')
sites['location_type'] = ['watershed' if basin.geometry.iloc[0].covers(p) else 'buffer_only' for p in sites.geometry]
sites['distance_to_basin_km'] = sites.distance(basin.geometry.iloc[0])/1000
sites['distance_to_centroid_km'] = sites.distance(basin.geometry.iloc[0].centroid)/1000
sites['usgs_url'] = 'https://waterdata.usgs.gov/monitoring-location/USGS-'+sites.site_no+'/'
sites = sites.sort_values(['location_type','site_no'])

assert OUTLET_SITE in set(sites.site_no), 'Outlet absent from exact station selection; review NLDI snap and coordinates.'


layers = {'watershed':basin,'search_buffer':buffer,'buffer_only_zone':ring,'usgs_sites':sites,
          'sites_in_basin':sites[sites.location_type=='watershed'].copy(), 'sites_buffer_only':sites[sites.location_type=='buffer_only'].copy()}
gpkg = OUT/'OakRidge.gpkg'
if gpkg.exists(): gpkg.unlink()
for name, frame in layers.items():
    frame.to_file(gpkg,layer=name,driver='GPKG')
    frame.to_crs(4326).to_file(OUT/(name+'.geojson'),driver='GeoJSON')
sites.drop(columns='geometry').to_csv(OUT/'usgs_station_catalog.csv',index=False)
summary = {'watershed_area_km2':area,'watershed_area_sqmi':area/2.589988110336,'published_usgs_area_sqmi':PUBLISHED_AREA_SQMI,
 'basin_sites':int((sites.location_type=='watershed').sum()),'buffer_only_sites':int((sites.location_type=='buffer_only').sum()),
 'total_sites':len(sites),'buffer_km':BUFFER_DISTANCE_KM,'crs':f'EPSG:{PROJECTED_CRS}','method':f'USGS NLDI unsimplified upstream basin for USGS-{OUTLET_SITE}; not a new DEM delineation',
 'scope':'All NWIS site types, all statuses, no parameter filter; exact polygon intersection after bounding-box query',
 'area_difference_pct':area_difference_pct, 'sources':log}
(OUT/'metadata.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='sources'},indent=2))



# Module 5-style interactive map, with separate station groups and USGS popups.
data = {k:json.loads(v.to_crs(4326).to_json()) for k,v in layers.items() if k in ['watershed','search_buffer','sites_in_basin','sites_buffer_only']}
page = '''<!doctype html><html><head><meta charset="utf-8"><title>Oak Ridge Reservoir watershed and USGS stations</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>body{margin:0;font:15px Arial}#map{height:88vh}header{padding:12px 20px}h2{margin:0 0 6px} .legend{background:white;padding:12px;line-height:1.6}</style></head><body>
<header><h2>Oak Ridge Reservoir contributing watershed</h2>AREA km² · INSIDE sites in basin · OUTSIDE sites in BUFFER_LABEL buffer only · All USGS site types and statuses</header><div id="map"></div>
<script>const data=DATA; const map=L.map('map');
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',{attribution:'Tiles © Esri and the GIS User Community'}).addTo(map);
const buf=L.geoJSON(data.search_buffer,{style:{color:'#3388cc',weight:1,fillOpacity:.16}}).addTo(map);
const basin=L.geoJSON(data.watershed,{style:{color:'#173d89',weight:3,fillOpacity:.35}}).addTo(map);
function safe(s){const d=document.createElement('div');d.textContent=s||'';return d.innerHTML}
function points(fc,color){return L.geoJSON(fc,{pointToLayer:(f,ll)=>L.circleMarker(ll,{radius:5,color:'#fff',weight:1,fillColor:color,fillOpacity:.9}),onEachFeature:(f,l)=>{const p=f.properties;l.bindTooltip(p.site_no+' '+p.station_nm);l.bindPopup('<b>USGS '+safe(p.site_no)+'</b><br>'+safe(p.station_nm)+'<br>Type: '+safe(p.site_tp_cd)+'<br>Zone: '+safe(p.location_type)+'<br>Distance to basin: '+Number(p.distance_to_basin_km).toFixed(2)+' km<br><a target="_blank" rel="noopener" href="'+p.usgs_url+'">USGS station page</a>')}}).addTo(map)}
const inside=points(data.sites_in_basin,'#16834b'),outside=points(data.sites_buffer_only,'#ed8b23');
L.control.layers(null,{'BUFFER_LABEL search buffer':buf,'Contributing watershed':basin,'USGS sites in basin':inside,'USGS sites in buffer only':outside}).addTo(map);
map.fitBounds(buf.getBounds());const legend=L.control({position:'bottomleft'});legend.onAdd=()=>{const d=L.DomUtil.create('div','legend');d.innerHTML='<span style="color:#16834b">●</span> USGS site in basin<br><span style="color:#ed8b23">●</span> USGS site in buffer only<br>Blue: watershed and BUFFER_LABEL buffer<br>Source: USGS NLDI / NWIS';return d};legend.addTo(map);</script></body></html>'''
page = page.replace('Oak Ridge Reservoir contributing watershed', html.escape(STUDY_NAME)).replace('BUFFER_LABEL', f'{BUFFER_DISTANCE_KM:g} km').replace('AREA',f'{area:.2f}').replace('INSIDE',str(summary['basin_sites'])).replace('OUTSIDE',str(summary['buffer_only_sites'])).replace('DATA',json.dumps(data))
(OUT/'OakRidge_map.html').write_text(page,encoding='utf-8')

